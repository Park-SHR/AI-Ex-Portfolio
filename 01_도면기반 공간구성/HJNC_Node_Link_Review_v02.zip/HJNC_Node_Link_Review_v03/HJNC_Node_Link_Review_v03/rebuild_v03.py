from pathlib import Path
import csv, json, re, math, collections, shutil, zipfile, hashlib
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.collections import LineCollection
from matplotlib.patches import Rectangle
import ezdxf

ROOT=Path(__file__).resolve().parent
SRC=ROOT
OUT=ROOT
SNAP=ROOT/'source_v02_snapshot'

O=np.array([180000000.,175000000.])

def rcsv(path):
    with open(path,encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
def wcsv(path,rows,fields=None):
    if fields is None:
        if not rows: return
        fields=list(rows[0].keys())
    with open(path,'w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(rows)
def nums_wkt(w):
    return list(map(float,re.findall(r'-?\d+(?:\.\d+)?',w)))
def line_coords(w):
    a=nums_wkt(w);return np.array([[a[0],a[1]],[a[2],a[3]]],float)
def wktline(p,q): return f'LINESTRING ({p[0]:.7f} {p[1]:.7f}, {q[0]:.7f} {q[1]:.7f})'

old_lanes=rcsv(SNAP/'lane_master_v02.csv')
old_dir={r['lane_id']:int(float(r['direction'])) for r in old_lanes}
dir_ev={r['evidence_id']:r for r in rcsv(SRC/'direction_evidence.csv')}
vertical_symbols=json.load(open(SRC/'vertical_symbols.json',encoding='utf-8'))
move_rules=rcsv(SNAP/'movement_rule_master_v02.csv')
old_zones=rcsv(SRC/'zone_master.csv')

# -----------------------------------------------------------------------------
# 1) Horizontal cross-bank normalization: HA/HB/HC same ordinal => one Hxxx.
#    Source structure is exceptionally regular: each bank has 33 lanes, same
#    ordinal directions, and max y spread < 0.85 local units.
# -----------------------------------------------------------------------------
byzone={z:[] for z in 'ABC'}
for r in old_lanes:
    if r['axis']=='H':
        c=line_coords(r['geometry_wkt']); r=dict(r); r['_coords']=c; r['_y']=float(c[0,1]); byzone[r['zone']].append(r)
for z in byzone: byzone[z].sort(key=lambda r:r['_y'])
assert all(len(byzone[z])==33 for z in 'ABC')

lanes=[]; hcross=[]
xmin=min(r['_coords'][:,0].min() for z in 'ABC' for r in byzone[z]); xmax=max(r['_coords'][:,0].max() for z in 'ABC' for r in byzone[z])
for i in range(33):
    src=[byzone[z][i] for z in 'ABC']
    dirs={int(float(r['direction'])) for r in src}
    assert len(dirs)==1, (i,dirs)
    ys=[r['_y'] for r in src]; cy=float(np.median(ys)); lid=f'H{i+1:03d}'
    ev=[]
    for r in src:
        ev.extend([e for e in r['source_evidence'].split(';') if e])
    ev=list(dict.fromkeys(ev))
    lanes.append(dict(lane_id=lid,axis='H',zone='YARD_MAIN',direction=dirs.pop(),direction_status='cross_bank_consensus',geometry_status='normalized_from_A_B_C',coords=[[float(xmin),cy],[float(xmax),cy]],source_lane_ids=';'.join(r['lane_id'] for r in src),source_evidence=';'.join(ev),normalization_max_offset=round(max(abs(y-cy) for y in ys),6)))
    for r in src:
        hcross.append(dict(previous_lane_id=r['lane_id'],canonical_lane_id=lid,source_zone=r['zone'],source_y=round(r['_y'],7),canonical_y=round(cy,7),offset=round(r['_y']-cy,7),direction=r['direction'],status='normalized_same_ordinal_cross_bank'))

# Vertical lanes retained from v0.2 audited 4x4 slots.
# Their v0.2 y-extents (480..870) were inferred and created 0.2~0.3-unit edge stubs.
# Trim to the first/last canonical horizontal lane centerline instead.
h_ymin=min(l['coords'][0][1] for l in lanes if l['axis']=='H')
h_ymax=max(l['coords'][0][1] for l in lanes if l['axis']=='H')
for r in old_lanes:
    if r['axis']!='V': continue
    c=line_coords(r['geometry_wkt']); x=float(c[0,0])
    lanes.append(dict(lane_id=r['lane_id'],axis='V',zone=r['zone'],direction=int(float(r['direction'])),direction_status=r['direction_status'],geometry_status=r['geometry_status']+';extent_trimmed_to_canonical_horizontal_envelope',coords=[[x,h_ymin],[x,h_ymax]],source_lane_ids=r['lane_id'],source_evidence=r['source_evidence'],normalization_max_offset=0.0))

lane_by_id={l['lane_id']:l for l in lanes}
for l in lanes:
    l['x1'],l['y1']=l['coords'][0];l['x2'],l['y2']=l['coords'][1]

# Horizontal road bands from large y gaps (>15); represents roadway clusters.
hsorted=sorted([l for l in lanes if l['axis']=='H'],key=lambda l:l['y1'])
bands=[];cur=[]
for l in hsorted:
    if cur and l['y1']-cur[-1]['y1']>15:
        bands.append(cur);cur=[]
    cur.append(l)
if cur:bands.append(cur)
roadbands=[]; lane_to_band={}
for bi,g in enumerate(bands,1):
    bid=f'RB{bi:02d}'
    for l in g:lane_to_band[l['lane_id']]=bid
    roadbands.append(dict(road_band_id=bid,y_min=round(min(x['y1'] for x in g),7),y_max=round(max(x['y1'] for x in g),7),lane_count=len(g),lane_ids=';'.join(x['lane_id'] for x in g),direction_pattern=';'.join(f"{x['lane_id']}:{'E' if x['direction']>0 else 'W' if x['direction']<0 else 'U'}" for x in g),status='geometry_grouped_from_lane_spacing'))
assert len(roadbands)==8
wcsv(OUT/'horizontal_lane_crosswalk.csv',hcross)
wcsv(OUT/'road_band_master.csv',roadbands)

# Lane master v0.3
lane_rows=[]
for l in lanes:
    lane_rows.append(dict(lane_id=l['lane_id'],axis=l['axis'],zone=l['zone'],road_band_id=lane_to_band.get(l['lane_id'],''),direction=l['direction'],direction_status=l['direction_status'],geometry_status=l['geometry_status'],source_lane_ids=l['source_lane_ids'],source_evidence=l['source_evidence'],normalization_max_offset=l['normalization_max_offset'],geometry_wkt=wktline(l['coords'][0],l['coords'][1])))
wcsv(OUT/'lane_master.csv',lane_rows)

# -----------------------------------------------------------------------------
# 2) Rebuild nodes/links after normalization. This removes duplicate links and
#    micro-segments caused by A/B/C y-coordinate offsets.
# -----------------------------------------------------------------------------
for l in lanes:l['cuts']=[0.0, math.dist(l['coords'][0],l['coords'][1])]

def intersect_hv(h,v):
    hx1,hx2=sorted([h['x1'],h['x2']]);vy1,vy2=sorted([v['y1'],v['y2']]);x=v['x1'];y=h['y1']
    if hx1-1e-8<=x<=hx2+1e-8 and vy1-1e-8<=y<=vy2+1e-8:return (x,y)
    return None
for h in [x for x in lanes if x['axis']=='H']:
    for v in [x for x in lanes if x['axis']=='V']:
        p=intersect_hv(h,v)
        if p:
            h['cuts'].append(abs(p[0]-h['x1']))
            v['cuts'].append(abs(p[1]-v['y1']))

nodes=[]; node_key={}; node_lane_sets=collections.defaultdict(set)
def node(p,lid):
    k=(round(float(p[0]),5),round(float(p[1]),5))
    if k not in node_key:
        nid=f'R3N{len(nodes)+1:05d}';node_key[k]=nid
        nodes.append(dict(node_id=nid,x_local=k[0],y_local=k[1],x_cad=O[0]+k[0]*1000,y_cad=O[1]+k[1]*1000))
    node_lane_sets[node_key[k]].add(lid);return node_key[k]

links=[]
for l in lanes:
    total=math.dist(l['coords'][0],l['coords'][1]); ux=(l['x2']-l['x1'])/total;uy=(l['y2']-l['y1'])/total
    cuts=sorted(set(round(c,7) for c in l['cuts']))
    for a,b in zip(cuts,cuts[1:]):
        if b-a<1e-6:continue
        p=np.array([l['x1']+ux*a,l['y1']+uy*a]);q=np.array([l['x1']+ux*b,l['y1']+uy*b])
        if l['direction']<0:p,q=q,p
        n1=node(p,l['lane_id']);n2=node(q,l['lane_id']);mid=(p+q)/2
        # nearest source evidence if available
        evs=[dir_ev[e] for e in l['source_evidence'].split(';') if e in dir_ev]
        if evs:
            g=min(evs,key=lambda e:(float(e['x'])-mid[0])**2+(float(e['y'])-mid[1])**2)
        else:g={}
        links.append(dict(link_id=f'R3L{len(links)+1:05d}',lane_id=l['lane_id'],from_node=n1,to_node=n2,direction='forward' if l['direction'] else 'unknown',direction_status=l['direction_status'],geometry_status=l['geometry_status'],length_local=round(float(b-a),6),distance_unit_status='terminal_coordinate_unit; metric scale not formally certified',width='',zone=l['zone'],road_band_id=lane_to_band.get(l['lane_id'],''),source_evidence=g.get('evidence_id',''),nearest_symbol_kind=g.get('kind',''),nearest_symbol_maneuvers=g.get('allowed_maneuvers',''),nearest_symbol_id=g.get('audit_symbol_id',''),source_handles=g.get('handle',''),analysis_routing_ready=1 if l['direction'] else 0,operational_routing_ready=0,geometry_wkt=wktline(p,q)))

# semantic node typing after line membership collected
node_rows=[]
network_xmin=min(l['x1'] for l in lanes); network_xmax=max(l['x2'] for l in lanes)
network_ymin=min(l['y1'] for l in lanes); network_ymax=max(l['y2'] for l in lanes)
for n in nodes:
    lids=sorted(node_lane_sets[n['node_id']]); axes={lane_by_id[x]['axis'] for x in lids}
    x=float(n['x_local']); y=float(n['y_local'])
    on_boundary=(abs(x-network_xmin)<1e-5 or abs(x-network_xmax)<1e-5 or abs(y-network_ymin)<1e-5 or abs(y-network_ymax)<1e-5)
    if len(lids)>=2 and axes=={'H','V'}:nt='NETWORK_BOUNDARY_INTERSECTION' if on_boundary else 'INTERSECTION_LANE_CROSSING'
    else:nt='LANE_ENDPOINT'
    hids=[x for x in lids if x.startswith('H')];vids=[x for x in lids if x.startswith('V')]
    rb=lane_to_band.get(hids[0],'') if hids else ''
    corridor=lane_by_id[vids[0]]['zone'] if vids else ''
    node_rows.append(dict(**n,node_type=nt,lane_ids=';'.join(lids),road_band_id=rb,corridor_id=corridor,connectivity='turn_table_controls_cross_lane_transition' if nt.startswith('INTERSECTION') else 'lane_endpoint'))
wcsv(OUT/'node_master.csv',node_rows)
wcsv(OUT/'link_master.csv',links)

# -----------------------------------------------------------------------------
# 3) Routing rules: separate analytical use from operational approval.
#    Vertical symbols can support logical vertical->horizontal candidates; no
#    physical turn curve / target-lane field approval is claimed.
# -----------------------------------------------------------------------------
inc=collections.defaultdict(list); out=collections.defaultdict(list)
for l in links:inc[l['to_node']].append(l);out[l['from_node']].append(l)
node_by={n['node_id']:n for n in node_rows}
# symbol rules by vertical lane
vrules=collections.defaultdict(list)
for r in move_rules:
    vrules[r['lane_id']].append(r)
for k in vrules:vrules[k].sort(key=lambda r:float(r['symbol_y']))

def upstream_rule(lane_id,y):
    dy=lane_by_id[lane_id]['direction']; rr=vrules.get(lane_id,[])
    cand=[r for r in rr if (y-float(r['symbol_y']))*dy>=-0.001]
    if not cand:return None
    return min(cand,key=lambda r:abs(y-float(r['symbol_y'])))

def horiz_dx(link):
    a=node_by[link['from_node']];b=node_by[link['to_node']];return int(np.sign(float(b['x_local'])-float(a['x_local'])))

turns=[];connectors=[]
for nid in node_by:
    for a in inc[nid]:
        for b in out[nid]:
            if a['link_id']==b['link_id']:continue
            same=a['lane_id']==b['lane_id']; move='cross_lane_transition'; perm='review_required'; analysis=0; operational=0; rule=None; sym=''; reason='Cross-lane movement lacks audited evidence'
            if same:
                move='straight'
                if a['lane_id'].startswith('V'):
                    rule=upstream_rule(a['lane_id'],float(node_by[nid]['y_local']))
                    if rule:
                        ok=str(rule['straight_allowed']).lower()=='true';sym=rule['rule_id']
                        perm='allowed_by_symbol' if ok else 'prohibited_by_symbol';analysis=1 if ok else 0
                        reason='Vertical straight continuation controlled by nearest upstream audited pavement symbol'
                    else:
                        perm='review_required';reason='No upstream audited vertical symbol found'
                else:
                    perm='allowed_same_lane_continuation';analysis=1;reason='Canonical horizontal lane continuity after A/B/C normalization'
            elif a['lane_id'].startswith('V') and b['lane_id'].startswith('H'):
                dy=lane_by_id[a['lane_id']]['direction']; dx=horiz_dx(b); move='left' if -dy*dx>0 else 'right'
                rule=upstream_rule(a['lane_id'],float(node_by[nid]['y_local']))
                if rule:
                    allowed=move in [x.strip() for x in rule['allowed_maneuvers'].split('|') if x.strip()];sym=rule['rule_id']
                    if allowed:
                        perm='analysis_candidate_by_symbol_and_direction';analysis=1
                        reason='Audited vertical pavement symbol permits movement and target horizontal link departs in matching direction; physical turn curve/field approval not verified'
                        connectors.append(dict(connector_id=f'R3C{len(connectors)+1:05d}',from_link=a['link_id'],via_node=nid,to_link=b['link_id'],movement=move,source_vertical_lane=a['lane_id'],target_horizontal_lane=b['lane_id'],road_band_id=lane_to_band.get(b['lane_id'],''),source_symbol=sym,target_selection_status='direction_matched_candidate',connector_geometry_status='logical_centerline_intersection_only',analysis_routing_enabled=1,operational_routing_enabled=0,field_verified=0))
                    else:
                        perm='prohibited_by_symbol';analysis=0;reason='Audited vertical pavement symbol prohibits this movement'
                else:
                    perm='review_required';reason='No upstream audited vertical pavement symbol found'
            elif a['lane_id'].startswith('H') and b['lane_id'].startswith('V'):
                # Do not invent horizontal-turn permissions. Keep explicit gap.
                move='horizontal_to_vertical_turn';perm='review_required_horizontal_turn';analysis=0;reason='Horizontal approach turn symbols were not comprehensively audited in v0.2/v0.3 source set'
            else:
                perm='lane_change_unmodeled';analysis=0;reason='Lane changes between parallel lanes are outside current graph model'
            turns.append(dict(via_node=nid,from_link=a['link_id'],to_link=b['link_id'],movement=move,permission=perm,symbol_permitted='' if not rule else (str(move in rule.get('allowed_maneuvers','').split('|')) if move in ['straight','left','right'] else ''),source_symbol=sym,analysis_routing_enabled=analysis,operational_routing_enabled=operational,reason=reason))
wcsv(OUT/'turn_permissions.csv',turns)
wcsv(OUT/'turn_connector_master.csv',connectors)

# Keep movement_rule_master but update connector semantics wording.
mr=[]
for r in move_rules:
    rr=dict(r);rr['connector_status']='logical_candidate_generated_if_direction_matches; physical_curve_unverified';mr.append(rr)
wcsv(OUT/'movement_rule_master.csv',mr)

# -----------------------------------------------------------------------------
# 4) Remaining-area evidence summary. Do not fabricate unsupported roads.
# -----------------------------------------------------------------------------
unassigned=rcsv(SRC/'unassigned_evidence.csv')
def area(x,y):
    x=float(x);y=float(y)
    if 150<=x<=380 and 820<=y<=1030:return 'REVIEW_GATE'
    if 380<=x<=1450 and 875<=y<=1010:return 'REVIEW_NORTH'
    if 350<=x<=1455 and 410<=y<=475:return 'REVIEW_APRON'
    return 'OTHER_EDGE_OR_COMPLEX'
area_rows=[]
for r in unassigned:
    rr=dict(r);rr['review_area']=area(r['x'],r['y']);area_rows.append(rr)
wcsv(OUT/'unresolved_area_evidence.csv',area_rows)
area_counts=collections.Counter(r['review_area'] for r in area_rows)

# -----------------------------------------------------------------------------
# 5) Basic quality checks and statistics.
# -----------------------------------------------------------------------------
# duplicate geometric directed links
sig=collections.Counter((r['from_node'],r['to_node'],r['lane_id']) for r in links)
dups=sum(v-1 for v in sig.values() if v>1)
lengths=np.array([float(r['length_local']) for r in links])
sem=collections.Counter(r['node_type'] for r in node_rows)
perm_counts=collections.Counter(r['permission'] for r in turns)
quality={
 'schema_version':'0.3-normalized-analysis-routing',
 'source_version':'0.2',
 'horizontal_source_lanes':99,
 'horizontal_canonical_lanes':33,
 'vertical_lanes':16,
 'total_lane_chains':49,
 'road_bands':len(roadbands),
 'nodes':len(node_rows),
 'links':len(links),
 'logical_turn_connectors':len(connectors),
 'duplicate_link_signatures':dups,
 'min_link_length_local':float(lengths.min()),
 'links_lt_0_2':int((lengths<.2).sum()),
 'links_lt_1_0':int((lengths<1).sum()),
 'node_types':dict(sem),
 'turn_permission_counts':dict(perm_counts),
 'analysis_routing_enabled_turn_rows':sum(int(r['analysis_routing_enabled']) for r in turns),
 'operational_routing_enabled_turn_rows':0,
 'max_horizontal_normalization_offset':max(float(r['normalization_max_offset']) for r in lane_rows if r['axis']=='H'),
 'unresolved_area_evidence_counts':dict(area_counts),
 'remaining_limits':[
  'Horizontal-to-vertical turn permissions are not comprehensively audited and remain disabled.',
  'Turn connector curves/turning radii/median crossings are logical candidates only, not field verified.',
  'Gate, north-side and apron roads remain evidence-only review areas because the current source set does not support a reliable complete lane graph there.',
  'Coordinate unit is terminal-coordinate-like but not formally certified from drawing metadata alone.'
 ]
}
assert dups==0
assert quality['links_lt_0_2']==0
assert len([r for r in lane_rows if r['axis']=='H'])==33
assert len([r for r in lane_rows if r['axis']=='V'])==16
(OUT/'validation.json').write_text(json.dumps(quality,ensure_ascii=False,indent=2),encoding='utf-8')

# Network JSON
network={
 'schema_version':quality['schema_version'],
 'coordinate_system':{
  'type':'LOCAL_CAD', 'cad_origin':O.tolist(),'local_scale_divisor':1000,
  'distance_unit_status':'terminal coordinate unit; meter-like scale supported by TOS alignment precheck but not formally certified',
  'tos_transform_candidate':None
 },
 'lanes':lane_rows,'road_bands':roadbands,'nodes':node_rows,'links':links,'turn_permissions':turns,'turn_connectors':connectors,
 'vertical_movement_symbols':vertical_symbols,
 'unresolved_area_evidence_counts':dict(area_counts)
}
(OUT/'network.json').write_text(json.dumps(network,ensure_ascii=False,indent=2),encoding='utf-8')

# Compact viewer data
compact={'lanes':[{'id':r['lane_id'],'p':line_coords(r['geometry_wkt']).tolist(),'axis':r['axis'],'direction':int(r['direction']),'evidence':len(r['source_evidence'].split(';')) if r['source_evidence'] else 0,'rules':[]} for r in lane_rows],
         'nodes':[{'id':n['node_id'],'x':float(n['x_local']),'y':float(n['y_local']),'type':n['node_type']} for n in node_rows],
         'links':[{'id':l['link_id'],'lane':l['lane_id'],'f':l['from_node'],'t':l['to_node'],'len':float(l['length_local']),'symbol':l['nearest_symbol_id'],'moves':l['nearest_symbol_maneuvers']} for l in links],
         'arrows':[], 'zones':old_zones,
         'symbols':[{k:r[k] for k in ['symbol_id','corridor','lane_slot','band','x','y','dy','movements','source_handles','geometry']} for r in vertical_symbols]}
for l in compact['lanes']:
    if l['id'].startswith('V'):
        l['rules']=[{'id':r['rule_id'],'y':float(r['symbol_y']),'moves':r['allowed_maneuvers']} for r in mr if r['lane_id']==l['id']]
(OUT/'viewer_data.json').write_text(json.dumps(compact,ensure_ascii=False),encoding='utf-8')

# -----------------------------------------------------------------------------
# 6) Visuals using original CAD geometry background.
# -----------------------------------------------------------------------------
G=json.load(open(SRC/'geometry.json',encoding='utf-8'));segs=[]
for e in G:
    p=(np.array(e['p'])-O)/1000
    if p[:,0].min()>1458 or p[:,0].max()<145 or p[:,1].min()>1015 or p[:,1].max()<410:continue
    segs.append(p)

def plot_network(name,bounds,detail=False):
    fig,ax=plt.subplots(figsize=(20,11));ax.add_collection(LineCollection(segs,colors='#aeb8c2',linewidths=.22,alpha=.55))
    for rb in roadbands:
        ax.axhspan(float(rb['y_min'])-1,float(rb['y_max'])+1,alpha=.025)
    for l in lanes:
        p=np.array(l['coords']);c='#087ca5' if l['axis']=='H' else '#bd6118';ax.plot(p[:,0],p[:,1],color=c,lw=1.05 if l['axis']=='H' else .95,alpha=.92)
        if l['axis']=='H':
            for t in (.28,.68):
                m=p[0]+(p[1]-p[0])*t;d=(p[1]-p[0]);d=d/np.linalg.norm(d)*l['direction'];ax.annotate('',xy=m+d*4,xytext=m-d*4,arrowprops=dict(arrowstyle='-|>',color=c,lw=.8,mutation_scale=6))
        if detail:ax.text(*p.mean(0),l['lane_id'],fontsize=6,color=c,rotation=90 if l['axis']=='V' else 0,clip_on=True)
    for r in vertical_symbols:
        if bounds[0]<r['x']<bounds[1] and bounds[2]<r['y']<bounds[3]:
            col='#9a3c91' if r['lane_slot'] in [2,4] else '#be6118'
            ax.add_collection(LineCollection([np.array(x) for x in r.get('geometry',[])],colors=col,linewidths=1.1))
    if detail:
        for n in node_rows:
            if bounds[0]<float(n['x_local'])<bounds[1] and bounds[2]<float(n['y_local'])<bounds[3]:ax.plot(float(n['x_local']),float(n['y_local']),'o',ms=1.6,color='#22364f')
    for z in old_zones:
        if z['zone_type']=='unresolved_road_area':
            x0,x1,y0,y1=map(float,[z['xmin'],z['xmax'],z['ymin'],z['ymax']]);ax.add_patch(Rectangle((x0,y0),x1-x0,y1-y0,alpha=.06));ax.text((x0+x1)/2,(y0+y1)/2,z['zone_id'],ha='center',fontsize=9)
    ax.set_xlim(bounds[0],bounds[1]);ax.set_ylim(bounds[2],bounds[3]);ax.set_aspect('equal');ax.grid(alpha=.12)
    ax.set_xlabel('Local terminal X (CAD normalized)');ax.set_ylabel('Local terminal Y (CAD normalized)')
    ax.set_title(f'HJNC lane graph v0.3 | 49 lane chains / {len(links):,} links / {len(node_rows):,} nodes\nHorizontal A/B/C bank normalization applied; logical turn candidates separated from operational approval',fontsize=13)
    fig.savefig(OUT/name,dpi=220,bbox_inches='tight');plt.close(fig)
plot_network('network_overview_v03.png',(145,1460,410,1020))
plot_network('network_detail_v03.png',(340,760,470,880),True)
plot_network('network_only_v03.png',(350,1458,475,878))

# -----------------------------------------------------------------------------
# 7) Reconstructed DXF v0.3.
# -----------------------------------------------------------------------------
doc=ezdxf.new('R2010');doc.units=0
for name,col in [('H_CANONICAL',4),('V_LANE_AXIS',30),('NODE_INTERSECTION',2),('NODE_ENDPOINT',8),('MANEUVER',6),('LABEL',7)]:doc.layers.new(name,dxfattribs={'color':col})
ms=doc.modelspace()
for l in lanes:
    p=np.array(l['coords'])*1000+O;ms.add_line(tuple(p[0]),tuple(p[1]),dxfattribs={'layer':'H_CANONICAL' if l['axis']=='H' else 'V_LANE_AXIS'})
for n in node_rows:
    ms.add_circle((float(n['x_cad']),float(n['y_cad'])),100,dxfattribs={'layer':'NODE_INTERSECTION' if n['node_type'].startswith('INTERSECTION') else 'NODE_ENDPOINT'})
for r in vertical_symbols:
    for pts in r['geometry']:
        pp=np.array(pts)*1000+O;ms.add_lwpolyline(pp.tolist(),dxfattribs={'layer':'MANEUVER'})
for l in lanes:
    p=np.array(l['coords']).mean(0)*1000+O;ms.add_text(l['lane_id'],dxfattribs={'layer':'LABEL','height':450,'insert':tuple(p),'rotation':90 if l['axis']=='V' else 0})
doc.saveas(OUT/'reconstructed_network_v03.dxf')

# -----------------------------------------------------------------------------
# 8) Optional TOS-to-CAD translation precheck using a bounded sample.
# -----------------------------------------------------------------------------
zip_path=OUT.parent/'TosIFB_Replay_all_20260106-20260108.zip'
align=None
if zip_path.exists():
    pts=[]; member='TosIFB_Replay_all_20260108/TosIFB_Replay_tosMessage.log'
    with zipfile.ZipFile(zip_path) as z, z.open(member) as f:
        for line in f:
            try:o=json.loads(line)
            except:continue
            if o.get('id')!='TOS-11-2':continue
            for d in o.get('data',[]):
                if str(d.get('equNo','')).startswith('YT'):
                    try:pts.append((float(d['x']),float(d['y'])))
                    except:pass
            if len(pts)>=50000:break
    P=np.array(pts[::5],float)
    H=np.array([np.array(l['coords']) for l in lanes if l['axis']=='H']);V=np.array([np.array(l['coords']) for l in lanes if l['axis']=='V'])
    def metrics(dx,dy):
        Q=P+np.array([dx,dy]);x=Q[:,0,None];y=Q[:,1,None]
        hx1=np.minimum(H[:,0,0],H[:,1,0])[None,:];hx2=np.maximum(H[:,0,0],H[:,1,0])[None,:];hy=H[:,0,1][None,:]
        cx=np.minimum(np.maximum(x,hx1),hx2);dh=np.hypot(x-cx,y-hy)
        vy1=np.minimum(V[:,0,1],V[:,1,1])[None,:];vy2=np.maximum(V[:,0,1],V[:,1,1])[None,:];vx=V[:,0,0][None,:]
        cy=np.minimum(np.maximum(y,vy1),vy2);dv=np.hypot(x-vx,y-cy)
        d=np.minimum(dh.min(1),dv.min(1));return float(np.median(d)),float(np.mean(d<=10)),float(np.mean(d<=20)),float(np.percentile(d,95))
    best=None
    for dx in np.arange(354,363.01,1):
        for dy in np.arange(466,475.01,1):
            m,c10,c20,p95=metrics(dx,dy);key=(m,-c10,p95)
            if best is None or key<best[0]:best=(key,dx,dy,m,c10,c20,p95)
    _,dx0,dy0,*_=best;best2=None
    for dx in np.arange(dx0-1,dx0+1.001,.25):
        for dy in np.arange(dy0-1,dy0+1.001,.25):
            m,c10,c20,p95=metrics(dx,dy);key=(m,-c10,p95)
            if best2 is None or key<best2[0]:best2=(key,float(dx),float(dy),m,c10,c20,p95)
    _,dx,dy,m,c10,c20,p95=best2
    align={'status':'empirical_translation_candidate_not_authoritative','source_member':member,'sample_points':len(P),'transform_formula':'cad_local_x = tos_x + dx; cad_local_y = tos_y + dy','dx':dx,'dy':dy,'median_nearest_lane_distance_local':m,'coverage_within_10_local':c10,'coverage_within_20_local':c20,'p95_distance_local':p95,'notes':['Optimization uses nearest reconstructed main-yard lane only.','High residuals include gate/north/apron points where graph is intentionally incomplete.','Do not treat as final coordinate calibration without control-point validation.']}
    (OUT/'coordinate_alignment_candidate.json').write_text(json.dumps(align,ensure_ascii=False,indent=2),encoding='utf-8')
    network['coordinate_system']['tos_transform_candidate']=align
    (OUT/'network.json').write_text(json.dumps(network,ensure_ascii=False,indent=2),encoding='utf-8')

# -----------------------------------------------------------------------------
# 9) Patch offline viewer DATA/title conservatively.
# -----------------------------------------------------------------------------
html=(SRC/'network_viewer.html').read_text(encoding='utf-8')
html=re.sub(r'const DATA=.*?;const cv=',lambda m:'const DATA='+json.dumps(compact,ensure_ascii=False)+';const cv=',html,flags=re.S)
html=re.sub(r'v0\.2 · \d+개 차선군 · [\d,]+개 Link · \d+개 Node · 세로 16차선 / 112개 구간별 표식 재검토',f'v0.3 · 49개 정규화 차선군 · {len(links):,}개 Link · {len(node_rows):,}개 Node · 세로 16차선 / 가로 33 canonical lanes',html)
html=html.replace('세로 차선의 직진·좌회전·우회전 표식을 반영했습니다. 선은 차선 축이며 실제 회전 연결곡선은 미확정입니다.','가로 A/B/C 중복 차선을 33개 canonical lane으로 정규화하고 세로 4차선 규칙을 유지했습니다. 논리적 회전 후보와 운영 승인 상태를 분리했습니다.')
(OUT/'network_viewer_v03.html').write_text(html,encoding='utf-8')

# -----------------------------------------------------------------------------
# 10) README + changelog.
# -----------------------------------------------------------------------------
readme=f'''# HJNC Node/Link 공간재구성 v0.3 — 정규화·분할오류 보정 및 분석용 Routing 후보 추가

## 이번 보정의 목적

v0.2의 세로 4차선·구간별 회전표식 판독은 유지하고, 검토 과정에서 확인된 **가로 A/B/C bank 중복**, **미세 Y offset으로 인한 초단 Link**, **Node 의미 구분 부족**, **회전 허용과 실제 Connector 상태 혼재**를 보정했다.

## 핵심 변경

1. **가로 99 lane → 33 canonical lane 정규화**
   - A/B/C 각 bank가 동일하게 33개 lane을 가지고 동일 ordinal의 방향도 일치한다.
   - 동일 ordinal의 y 편차는 최대 {quality['max_horizontal_normalization_offset']:.3f} local unit 이내로 확인되어 median y로 정규화했다.
   - 원본 HA/HB/HC ID와 canonical H001~H033 대응은 `horizontal_lane_crosswalk.csv`에 보존했다.

2. **도로 band 8개 정의**
   - 큰 y 간격을 기준으로 33개 가로 lane을 8개 물리적 도로 묶음(`RB01~RB08`)으로 그룹화했다.
   - 이는 lane을 합치는 것이 아니라 교차로/회전 후보를 road-level로 해석하기 위한 상위 grouping이다.

3. **Node/Link 재생성 및 초단 Link 제거**
   - v0.2: 804 Node / 1,481 Link
   - v0.3: {len(node_rows)} Node / {len(links)} Link
   - 최소 Link 길이: {quality['min_link_length_local']:.3f} local unit
   - 0.2 미만 Link: {quality['links_lt_0_2']}건, 1.0 미만 Link: {quality['links_lt_1_0']}건
   - 동일 directed link signature 중복: {quality['duplicate_link_signatures']}건

4. **Node 의미 분류**
   - `INTERSECTION_LANE_CROSSING`: 내부 가로/세로 lane 중심선 교차점
   - `NETWORK_BOUNDARY_INTERSECTION`: 현재 재구성 범위 외곽의 가로/세로 교차점
   - `LANE_ENDPOINT`: 독립 lane 끝점이 존재할 경우 사용되는 예비 유형
   - 따라서 Node 수를 실제 교차로 개수로 오해하지 않도록 구조화했다.

5. **회전 Connector 후보 분리**
   - `turn_connector_master.csv`에 세로 접근 표식 + 대상 가로 lane 진행방향이 함께 맞는 logical connector 후보 {len(connectors)}건을 생성했다.
   - `analysis_routing_enabled=1`은 연구용 Graph 탐색에 사용할 수 있는 후보라는 뜻이다.
   - `operational_routing_enabled=0`, `field_verified=0`은 유지한다. 실제 회전 곡률·중앙분리대·장애물·현장 허용 여부를 현재 도면만으로 확정할 수 없기 때문이다.

6. **분석용 / 운영용 routing 상태 분리**
   - 같은 lane의 직진 연속은 분석용으로 활성화.
   - 세로 접근의 좌/우회전은 audited symbol이 허용하고 대상 horizontal link 방향이 일치할 때만 분석 후보 활성화.
   - 표식이 금지한 움직임은 차단.
   - **가로→세로 회전은 전체 수평 접근표식 audit이 없으므로 추정하지 않고 비활성화**했다.

## 현재 수치

- canonical lane chain: 49개 (가로 33 + 세로 16)
- road band: 8개
- Node: {len(node_rows)}개
- Link: {len(links)}개
- logical turn connector candidate: {len(connectors)}개
- 분석용 활성 turn-table row: {quality['analysis_routing_enabled_turn_rows']}개
- 운영용 활성: 0개

## TOS 좌표 정합 사전검증
'''
if align:
    readme+=f'''3일 Replay ZIP 중 2026-01-08 앞부분의 YT 좌표를 표본으로 translation-only 정합을 탐색했다. 현재 후보는 `CAD local = TOS + ({align['dx']:.2f}, {align['dy']:.2f})`이며, 표본의 reconstructed main-yard lane 최근접 거리 중앙값은 {align['median_nearest_lane_distance_local']:.2f}, 10-unit 이내 비율은 {align['coverage_within_10_local']*100:.1f}%다. 이 값은 **control point를 이용한 공식 좌표변환이 아니라 Map Matching 전처리를 위한 경험적 후보**다. 미재구성 Gate/North/Apron 좌표가 잔차에 포함된다.
'''
else:
    readme+='Replay ZIP을 찾지 못해 이번 패키지에서는 좌표 정합 사전검증을 수행하지 않았다.\n'
readme+=f'''
## 현재 자료만으로 완료할 수 없는 부분

현재 source에서 근거가 부족한 부분은 임의로 완성하지 않았다.

- **가로 접근 → 세로 통로 회전 표식 전체 audit**: 미완. 현재 `review_required_horizontal_turn`로 명시.
- **실제 회전 곡선 / 회전반경 / 중앙분리대 통과 / 장애물**: logical candidate만 생성, 운영 routing은 비활성.
- **Gate / North / Apron 전체 lane graph**: v0.2의 unassigned evidence를 `unresolved_area_evidence.csv`로 영역별 재분류했지만, 현재 DXF 증거만으로 신뢰성 있는 전체 중심선을 자동 확정하기 어렵다.
- **좌표계 공식 인증**: TOS 정합 후보는 만들었으나 현장 control point 또는 공식 좌표변환식 확인이 필요하다.

이 부분을 억지로 채우면 연구용 Graph의 재현성과 논문 설명가능성이 오히려 떨어지므로, **근거 있는 보정과 근거 없는 추정을 구분**했다.

## 주요 산출물

- `lane_master.csv` — canonical 49 lane
- `horizontal_lane_crosswalk.csv` — HA/HB/HC → H001~H033
- `road_band_master.csv` — 8개 가로 도로 band
- `node_master.csv` — semantic node type 포함
- `link_master.csv` — 초단 link 제거 후 분할 link
- `movement_rule_master.csv` — 112개 세로 구간별 회전 규칙
- `turn_permissions.csv` — 모든 directed transition 상태
- `turn_connector_master.csv` — symbol+direction 기반 logical turn candidate
- `unresolved_area_evidence.csv` — Gate/North/Apron 등 미재구성 근거
- `coordinate_alignment_candidate.json` — TOS↔CAD translation 사전 후보
- `network.json` — 전체 통합 구조
- `network_viewer_v03.html` — 오프라인 검토 Viewer
- `reconstructed_network_v03.dxf` — CAD overlay
- `network_overview_v03.png`, `network_detail_v03.png`, `network_only_v03.png`
- `validation.json` — 품질·잔여 한계 요약

## 연구 적용 권장 상태

v0.3는 **Node/Link 기반 공간재구성 및 Map Matching 후보망**으로 사용할 수 있다. 다만 실제 운영 최단경로용 Graph로 사용하기 전에는 horizontal-turn audit와 현장/도면 기반 connector verification을 추가해야 한다.
'''
(OUT/'README_KO.md').write_text(readme,encoding='utf-8')

changelog=f'''# CHANGELOG v0.3\n\n- normalized 99 horizontal bank-local lanes into 33 canonical lanes\n- removed cross-bank duplicate geometry and micro-segments\n- introduced 8 horizontal road bands\n- rebuilt R3 node/link IDs\n- classified nodes semantically\n- added logical turn connector master and analysis-vs-operational routing flags\n- kept horizontal-to-vertical turns disabled where source evidence is incomplete\n- regrouped unresolved area evidence\n- added empirical TOS translation precheck when Replay ZIP is available\n'''
(OUT/'CHANGELOG_v03.md').write_text(changelog,encoding='utf-8')

# Remove old v0.2 generated files that could be confused with current v0.3; keep audit inputs/images and source scripts.
for fn in ['network_overview.png','network_detail.png','network_only.png','reconstructed_network.dxf']:
    p=OUT/fn
    if p.exists():p.unlink()
# retain original build_network.py and finalize_revision.py as source history, but label them.
(OUT/'SOURCE_VERSION_NOTE.txt').write_text('build_network.py and finalize_revision.py are v0.2 source-history scripts. Use the v0.3 generated masters in this package.\n',encoding='utf-8')

# Package zip
zip_out=OUT.parent/'HJNC_Node_Link_Review_v03_rebuilt.zip'
if zip_out.exists():zip_out.unlink()
with zipfile.ZipFile(zip_out,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for p in sorted(OUT.rglob('*')):
        if p.is_file(): z.write(p, arcname=f'HJNC_Node_Link_Review_v03/{p.relative_to(OUT)}')
print(json.dumps({'zip':str(zip_out),'quality':quality,'align':align},ensure_ascii=False,indent=2))
