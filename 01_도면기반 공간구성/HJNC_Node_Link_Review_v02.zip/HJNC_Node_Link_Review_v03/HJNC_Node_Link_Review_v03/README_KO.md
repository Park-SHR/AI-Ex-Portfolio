# HJNC Node/Link 공간재구성 v0.3 — 정규화·분할오류 보정 및 분석용 Routing 후보 추가

## 이번 보정의 목적

v0.2의 세로 4차선·구간별 회전표식 판독은 유지하고, 검토 과정에서 확인된 **가로 A/B/C bank 중복**, **미세 Y offset으로 인한 초단 Link**, **Node 의미 구분 부족**, **회전 허용과 실제 Connector 상태 혼재**를 보정했다.

## 핵심 변경

1. **가로 99 lane → 33 canonical lane 정규화**
   - A/B/C 각 bank가 동일하게 33개 lane을 가지고 동일 ordinal의 방향도 일치한다.
   - 동일 ordinal의 y 편차는 최대 0.693 local unit 이내로 확인되어 median y로 정규화했다.
   - 원본 HA/HB/HC ID와 canonical H001~H033 대응은 `horizontal_lane_crosswalk.csv`에 보존했다.

2. **도로 band 8개 정의**
   - 큰 y 간격을 기준으로 33개 가로 lane을 8개 물리적 도로 묶음(`RB01~RB08`)으로 그룹화했다.
   - 이는 lane을 합치는 것이 아니라 교차로/회전 후보를 road-level로 해석하기 위한 상위 grouping이다.

3. **Node/Link 재생성 및 초단 Link 제거**
   - v0.2: 804 Node / 1,481 Link
   - v0.3: 528 Node / 1007 Link
   - 최소 Link 길이: 2.789 local unit
   - 0.2 미만 Link: 0건, 1.0 미만 Link: 0건
   - 동일 directed link signature 중복: 0건

4. **Node 의미 분류**
   - `INTERSECTION_LANE_CROSSING`: 내부 가로/세로 lane 중심선 교차점
   - `NETWORK_BOUNDARY_INTERSECTION`: 현재 재구성 범위 외곽의 가로/세로 교차점
   - `LANE_ENDPOINT`: 독립 lane 끝점이 존재할 경우 사용되는 예비 유형
   - 따라서 Node 수를 실제 교차로 개수로 오해하지 않도록 구조화했다.

5. **회전 Connector 후보 분리**
   - `turn_connector_master.csv`에 세로 접근 표식 + 대상 가로 lane 진행방향이 함께 맞는 logical connector 후보 201건을 생성했다.
   - `analysis_routing_enabled=1`은 연구용 Graph 탐색에 사용할 수 있는 후보라는 뜻이다.
   - `operational_routing_enabled=0`, `field_verified=0`은 유지한다. 실제 회전 곡률·중앙분리대·장애물·현장 허용 여부를 현재 도면만으로 확정할 수 없기 때문이다.

6. **분석용 / 운영용 routing 상태 분리**
   - 같은 lane의 직진 연속은 분석용으로 활성화.
   - 세로 접근의 좌/우회전은 audited symbol이 허용하고 대상 horizontal link 방향이 일치할 때만 분석 후보 활성화.
   - 표식이 금지한 움직임은 차단.
   - **가로→세로 회전은 전체 수평 접근표식 audit이 없으므로 추정하지 않고 비활성화**했다.

## 현재 수치

- canonical lane chain: 49개 (가로 33 + 세로 16)
- road band: 8개
- Node: 528개
- Link: 1007개
- logical turn connector candidate: 201개
- 분석용 활성 turn-table row: 951개
- 운영용 활성: 0개

## TOS 좌표 정합 사전검증
3일 Replay ZIP 중 2026-01-08 앞부분의 YT 좌표를 표본으로 translation-only 정합을 탐색했다. 현재 후보는 `CAD local = TOS + (358.00, 469.75)`이며, 표본의 reconstructed main-yard lane 최근접 거리 중앙값은 3.59, 10-unit 이내 비율은 64.7%다. 이 값은 **control point를 이용한 공식 좌표변환이 아니라 Map Matching 전처리를 위한 경험적 후보**다. 미재구성 Gate/North/Apron 좌표가 잔차에 포함된다.

## 현재 자료만으로 완료할 수 없는 부분

현재 source에서 근거가 부족한 부분은 임의로 완성하지 않았다.

- **가로 접근 → 세로 통로 회전 표식 전체 audit**: 미완. 현재 `review_required_horizontal_turn`로 명시.
- **실제 회전 곡선 / 회전반경 / 중앙분리대 통과 / 장애물**: logical candidate만 생성, 운영 routing은 비활성.
- **Gate / North / Apron 전체 lane graph**: v0.2의 unassigned evidence를 `unresolved_area_evidence.csv`로 영역별 재분류했지만, 현재 DXF 증거만으로 신뢰성 있는 전체 중심선을 자동 확정하기 어렵다.
- **좌표계 공식 인증**: TOS 정합 후보는 만들었으나 현장 control point 또는 공식 좌표변환식 확인이 필요하다.

이 부분을 억지로 채우면 연구용 Graph의 재현성과 논문 설명가능성이 오히려 떨어지므로, **근거 있는 보정과 근거 없는 추정을 구분**했다.

## 주요 산출물

- `lane_master.csv` — canonical 49 lane
- `horizontal_lane_crosswalk.csv` — HA/HB/HC → H001~H033
- `road_band_master.csv` — 8개 가로 도로 band
- `node_master.csv` — semantic node type 포함
- `link_master.csv` — 초단 link 제거 후 분할 link
- `movement_rule_master.csv` — 112개 세로 구간별 회전 규칙
- `turn_permissions.csv` — 모든 directed transition 상태
- `turn_connector_master.csv` — symbol+direction 기반 logical turn candidate
- `unresolved_area_evidence.csv` — Gate/North/Apron 등 미재구성 근거
- `coordinate_alignment_candidate.json` — TOS↔CAD translation 사전 후보
- `network.json` — 전체 통합 구조
- `network_viewer_v03.html` — 오프라인 검토 Viewer
- `reconstructed_network_v03.dxf` — CAD overlay
- `network_overview_v03.png`, `network_detail_v03.png`, `network_only_v03.png`
- `validation.json` — 품질·잔여 한계 요약

## 연구 적용 권장 상태

v0.3는 **Node/Link 기반 공간재구성 및 Map Matching 후보망**으로 사용할 수 있다. 다만 실제 운영 최단경로용 Graph로 사용하기 전에는 horizontal-turn audit와 현장/도면 기반 connector verification을 추가해야 한다.
