# v0.3 검증 요약

- 가로 source lane: 99 → canonical 33
- 세로 lane: 16 유지
- 총 lane chain: 49
- Road band: 8
- Node: 528
  - 내부 lane 교차: 434
  - 네트워크 외곽 교차: 94
- Link: 1,007
- logical turn connector candidate: 201
- 동일 directed link 중복: 0
- 0.2 미만 Link: 0
- 1.0 미만 Link: 0
- 최소 Link 길이: 2.788887 local unit
- 가로 정규화 최대 편차: 0.692977 local unit
- 분석용 활성 turn-table row: 951
- 운영용 활성 turn-table row: 0

## 보정 완료 항목

1. A/B/C bank 중복 horizontal lane 정규화
2. 미세 Y offset에 의해 생긴 중복/초단 Link 제거
3. 세로 lane의 임의 480~870 extent를 첫/마지막 canonical horizontal lane까지 trim
4. Node 의미 분류
5. 세로 표식 기반 logical turn connector 후보 분리
6. 분석용 routing과 운영 승인 routing 분리
7. TOS 좌표 translation 사전 후보 생성

## 근거 부족으로 보류한 항목

- Horizontal approach → vertical corridor 회전 허용의 전체 audit
- 실제 회전곡선/회전반경/중앙분리대/장애물 확인
- Gate/North/Apron 전체 lane graph
- 공식 좌표변환식 확정

보류 항목은 임의 추정으로 채우지 않고 별도 review 상태로 남겼다.
