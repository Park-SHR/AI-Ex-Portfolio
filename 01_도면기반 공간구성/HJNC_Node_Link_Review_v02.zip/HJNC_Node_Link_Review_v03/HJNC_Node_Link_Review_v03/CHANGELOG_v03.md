# CHANGELOG v0.3

- normalized 99 horizontal bank-local lanes into 33 canonical lanes
- removed cross-bank duplicate geometry and micro-segments
- introduced 8 horizontal road bands
- rebuilt R3 node/link IDs
- classified nodes semantically
- added logical turn connector master and analysis-vs-operational routing flags
- kept horizontal-to-vertical turns disabled where source evidence is incomplete
- regrouped unresolved area evidence
- added empirical TOS translation precheck when Replay ZIP is available
