from pathlib import Path
import json,csv,collections,re,shutil,hashlib
import numpy as np,ezdxf
P=Path(__file__).resolve().parent;ROOT=P.parent
net=json.load(open(P/'network.json'));v=json.load(open(P/'viewer_data.json'));sy=json.load(open(P/'vertical_symbols.json'));summary=json.load(open(P/'validation.json'))
def csvout(name,rows):
 with open(P/name,'w',encoding='utf-8-sig',newline='') as f:w=csv.DictWriter(f,fieldnames=rows[0]);w.writeheader();w.writerows(rows)
# Stable lane mapping: old second detected internal lane corresponds to slot 3, not slot 2.
cross=[]
for i in range(1,5):
 for j in range(1,5):
  old=f'V{i}{j:02d}'
  if i in [2,3]:old={1:f'V{i}01',2:'',3:f'V{i}02',4:''}[j]
  cross.append(dict(previous_lane_id=old,revised_lane_id=f'V{i}{j:02d}',corridor=f'C{i}',slot_left_to_right=j,change='restored_turn_only_lane' if not old else ('renumbered_to_physical_slot' if old!=f'V{i}{j:02d}' else 'movement_rules_added')))
csvout('lane_id_crosswalk.csv',cross)
# Per-lane summary; preserve variation between bands rather than majority-vote it away.
lanesummary=[]
for c in range(1,5):
 for slot in range(1,5):
  rr=sorted([r for r in sy if r['corridor']==f'C{c}' and r['lane_slot']==slot],key=lambda r:r['band'])
  lanesummary.append(dict(lane_id=f'V{c}{slot:02d}',corridor=f'C{c}',lane_slot=slot,shaft_x_local=float(np.median([r['x'] for r in rr])),approach=rr[0]['approach'],band_1=rr[0]['movements'],band_2=rr[1]['movements'],band_3=rr[2]['movements'],band_4=rr[3]['movements'],band_5=rr[4]['movements'],band_6=rr[5]['movements'],band_7=rr[6]['movements'],has_rule_variation=len({r['movements'] for r in rr})>1))
csvout('vertical_lane_summary.csv',lanesummary)
# CAD overlay: lane axes are separate from the original maneuver-symbol outlines.
doc=ezdxf.new('R2010');doc.units=0
for name,col in [('H_LANE',4),('V_LANE_AXIS',30),('NODE',2),('MANEUVER',6),('LABEL',7)]:doc.layers.new(name,dxfattribs={'color':col})
nm={n['node_id']:n for n in net['nodes']}
for l in net['links']:
 a,b=nm[l['from_node']],nm[l['to_node']];doc.modelspace().add_line((a['x_cad'],a['y_cad']),(b['x_cad'],b['y_cad']),dxfattribs={'layer':'V_LANE_AXIS' if l['lane_id'].startswith('V') else 'H_LANE'})
for n in net['nodes']:doc.modelspace().add_circle((n['x_cad'],n['y_cad']),110,dxfattribs={'layer':'NODE'})
for r in sy:
 for pts in r['geometry']:doc.modelspace().add_lwpolyline((np.array(pts)*1000+[180000000,175000000]).tolist(),dxfattribs={'layer':'MANEUVER'})
for l in v['lanes']:
 p=np.array(l['p']).mean(0)*1000+[180000000,175000000];doc.modelspace().add_text(l['id'],dxfattribs={'layer':'LABEL','height':500,'insert':p,'rotation':90 if l['axis']=='V' else 0})
doc.saveas(P/'reconstructed_network.dxf')
# Revise the prior offline viewer, retaining its embedded basemap and pan/zoom controls.
template=P/'viewer_template.html'
if not template.exists():shutil.copy2(ROOT/'output/network_viewer.html',template)
html=template.read_text();v['symbols']=[{k:r[k] for k in ['symbol_id','corridor','lane_slot','band','x','y','dy','movements','source_handles','geometry']} for r in sy]
html=re.sub(r'const DATA=.*?;const cv=',lambda m:'const DATA='+json.dumps(v,ensure_ascii=False)+';const cv=',html,flags=re.S)
html=html.replace('111개 차선군 · 1,058개 Link · 641개 Node · 438개 방향 근거',f"v0.2 · {summary['lanes']}개 차선군 · {summary['links']:,}개 Link · {summary['nodes']}개 Node · 세로 16차선 / 112개 구간별 표식 재검토")
html=html.replace('검토용 재구성: 주 야드 중심. 회전 허용·미재구성 구역·좌표 단위는 확정 전입니다.','세로 차선의 직진·좌회전·우회전 표식을 반영했습니다. 선은 차선 축이며 실제 회전 연결곡선은 미확정입니다.')
html=html.replace('<option value="gate">','<option value="c2">내부 통로 C2 · 4차선</option><option value="c3">내부 통로 C3 · 4차선</option><option value="gate">')
html=html.replace("for(const t of [.25,.65])arrow", "for(const t of (l.axis==='H'?[.25,.65]:[]))arrow")
needle="if(document.getElementById('arrows').checked)for(const a of DATA.arrows)"
html=html.replace(needle,"for(const r of DATA.symbols){let color=['C2','C3'].includes(r.corridor)&&[2,4].includes(r.lane_slot)?'#a23c95':'#b46019';for(const p of r.geometry)for(let j=1;j<p.length;j++)line(p[j-1],p[j],color,S>4?1.7:1);if(S>14){let p=screen(r.x,r.y-r.dy*.4);ctx.font='12px sans-serif';ctx.fillStyle=color;ctx.fillText(r.corridor+'-'+r.lane_slot+' '+r.movements.replaceAll('straight','S').replaceAll('left','L').replaceAll('right','R'),p[0]-15,p[1]+(r.dy>0?18:-12))}}\n"+needle)
html=html.replace('파랑: 가로 차선 / 주황: 세로 차선 / 보라: CAD 방향표시 / 황색 영역: 미재구성','파랑: 가로 차선 / 주황: 세로 차선 축 / 자주색 화살표: 복원한 회전 전용 차선 / 황색 영역: 미재구성')
html=html.replace('기하학적 교차점은 회전 허용을 의미하지 않습니다.','S=직진, L=좌회전, R=우회전 (운전자 진행 방향 기준). 표식으로 금지된 움직임은 전이표에 차단 표시했습니다. 기하학적 교차점은 특정 대상 차선과의 회전 연결을 확정하지 않습니다.')
html=html.replace('gate:[145,400,820,1020]', 'c2:[717,738,770,785],c3:[1079,1099,770,785],gate:[145,400,820,1020]')
html=html.replace('· 중심선 및 회전허용 검토 필요', '· 인근 구간 표식 ${best.symbol||"해당 없음"}: ${best.moves||"이번 검토 대상 아님"} · 회전 연결곡선 미확정')
# For selected vertical links display all seven band rules in addition to nearest-symbol info.
html=html.replace('· 회전 연결곡선 미확정`;draw()', '· 회전 연결곡선 미확정`;const lane=DATA.lanes.find(x=>x.id===best.lane);if(lane&&lane.rules.length)document.getElementById("detail").textContent+=" / 해당 차선의 구간별 표식: "+lane.rules.map(r=>r.id+"="+r.moves).join(", ");draw()')
(P/'network_viewer.html').write_text(html)
# Meaningful consistency checks.
assert len(sy)==112
assert collections.Counter((r['corridor'],r['lane_slot']) for r in sy)==collections.Counter({(f'C{c}',j):7 for c in range(1,5) for j in range(1,5)})
assert all(set(r['movements'].split('|'))<={'straight','left','right'} for r in sy)
for c in ['C2','C3']:
 assert all(r['movements']=='left' for r in sy if r['corridor']==c and r['lane_slot']==2)
 assert all(r['movements']=='right' for r in sy if r['corridor']==c and r['lane_slot']==4)
assert all(t['routing_enabled']==0 for t in net['turn_permissions'])
assert all(t['symbol_permitted'] is False for t in net['turn_permissions'] if t['permission']=='prohibited_by_symbol')
summary.update(vertical_symbols_per_corridor=28,restored_vertical_lanes=4,restored_turn_only_symbols=28,audit_coverage='4 corridors x 4 slots x 7 bands; not every road in drawing',turn_connectors_verified=False)
(P/'validation.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2))
# Reproducible instructions, known limits, and concrete correction record.
text=f'''# 항만 야드 도로망 수정 v0.2 — 세로 4차선 및 회전 표식 재검토

## 결론

사용자가 지적한 누락이 맞다. v0.1은 두 내부 세로 통로 C2·C3에서 각각 4차선 중 2차선만 추출했다. 직진·복합 화살표는 폴리라인으로 잡혔지만 좌회전 전용·우회전 전용 표식은 LINE, ARC, 여러 LWPOLYLINE으로 나뉘어 있어 차선 추출에서 빠졌다. 단순 직선 도로 연결만으로 회전 규칙을 표현한 부분도 수정했다.

네 세로 통로에서 각각 4차선 × 7개 구간의 **112개 표식**을 재판독했고, 누락된 4개 차선과 28개 구간별 회전 전용 표식을 복원했다. C1~C4는 도면 왼쪽부터의 분석용 통로 ID이며 공식 현장 명칭이 아니다. 각 통로의 차선 1~4도 도면 왼쪽부터 번호를 붙였다. band 1~7은 도면 아래쪽부터 위쪽이다.

## 내부 통로의 차선 규칙

| 차선 | 접근 방향 | C2 표식 | C3 표식 |
|---|---|---|---|
| 1 | 도면 아래 방향 (−Y) | 7구간 모두 직진+좌회전 | 1·5구간 직진+좌회전, 나머지 직진 |
| 2 | 도면 아래 방향 (−Y) | 7구간 모두 좌회전 전용 | 7구간 모두 좌회전 전용 |
| 3 | 도면 위 방향 (+Y) | 7구간 모두 직진 | 1~6구간 직진, 7구간 좌회전 전용 |
| 4 | 도면 위 방향 (+Y) | 7구간 모두 우회전 전용 | 7구간 모두 우회전 전용 |

좌·우회전은 화면 왼쪽·오른쪽이 아니라 **운전자 진행 방향 기준**이다. 예를 들어 −Y로 내려오다가 +X로 꺾으면 좌회전이며, +Y로 올라가다가 +X로 꺾으면 우회전이다. 첨부 상세도에 보이는 오른쪽 방향 화살표라도 두 접근 방향의 의미가 서로 다르다.

## 외측 통로와 예외

- C1-1: 1구간 좌회전 전용, 2~7구간 직진.
- C1-2: 전 구간 좌회전 전용. C1-3: 전 구간 직진. C1-4: 전 구간 직진+우회전.
- C4-1: 1구간 직진+우회전, 2~7구간 직진. C4-2: 전 구간 직진.
- C4-3, C4-4: 1~6구간 직진, 7구간 좌회전 전용.
- 차선 단위로 한 가지 회전 규칙을 전체 길이에 복사하지 않았다. 112개 접근 표식 각각에 허용 움직임을 저장했다.

## 데이터 변경

| 항목 | v0.1 | v0.2 |
|---|---:|---:|
| 가로 차선군 | 99 | {summary['horizontal_lanes']} |
| 세로 차선군 | 12 | {summary['vertical_lanes']} |
| 전체 차선군 | 111 | {summary['lanes']} |
| Node | 641 | {summary['nodes']} |
| 분할 Link | 1,058 | {summary['links']:,} |

Node와 Link 증가는 복원된 차선의 기하학적 교차점을 추가해 다시 분할한 결과다. 이 숫자를 실제 교차로 또는 독립 차선 개수로 해석하지 않는다.

Node/Link ID는 R2N/R2L 접두어로 새로 작성했다. v0.1 ID와 혼용하면 안 된다. 가로 차선군 ID는 유지했다. 기존 V202는 새 V203, 기존 V302는 새 V303에 대응한다. 새 V202/V204/V302/V304가 누락 복원 차선이다. lane_id_crosswalk.csv에 대응을 기록했다.

## 좌표·모델·회전 연결의 상태

- 원 CAD 좌표를 보존. 보기 좌표=(CAD−[180000000,175000000])/1000.
- INSUNITS 헤더=2(feet)와 도면의 크기·주석이 일관되지 않아 실제 단위는 미검증이다. length_m_assuming_mm는 mm 가정 시의 거리이며 확정 m 값이 아니다.
- 도면 표식의 차선 위치와 접근·회전 방향은 이번 재검토 근거다. 차선 중심선 길이와 교차로 내부 연장은 여전히 추정이다.
- 선 그림에서 세로 축이 이어져 있다고 직진을 허용한 것은 아니다. 회전 전용 차선은 movement_rule_master에 straight_allowed=False로 저장했다.
- turn_permissions는 세로 진입 Link에서 직진/좌회전/우회전을 분류하고 접근 방향 상류의 표식을 적용한다. 표식이 금지하는 전이 {summary['symbol_prohibited_transitions']}건을 prohibited_by_symbol로 표시했다. 표식과 다음 교차영역의 대응은 기하학적 후보이며, 개별 대상 차로의 연결곡선·차로 변경·중앙분리대 통과는 별도 검증이 필요하다.
- 표식상 허용은 symbol_permits_connector_unverified로 구분한다. routing_enabled=0 및 routing_ready=0을 유지했다. **회전 의미 판독 완료와 실제 주행 가능한 회전 연결곡선 확정은 구분한다.**
- 게이트·북측 구역·apron, 가로 차선의 전체 회전 규칙, TOS 좌표 정합은 이번 수정 범위에 포함되지 않는다. 현재 자료를 완성된 전 터미널 도로망으로 해석하지 않는다.

## 파일

- `vertical_four_lane_detail.png`: C2/C3 동일 구간의 실제 CAD 표식 확대. 자주색이 복원한 전용 차선. S=직진, L=좌회전, R=우회전.
- `vertical_symbol_atlas.png`: 네 통로×7개 구간의 112개 원본 표식 전체 대조.
- `vertical_symbols.csv/json`: 차선·구간·접근 방향·허용 움직임·원본 CAD handles. JSON에는 표식 도형도 포함.
- `vertical_lane_summary.csv`: 16개 세로 차선의 구간 1~7 규칙 비교.
- `movement_rule_master.csv`: 112개 구간별 straight/left/right 허용표.
- `lane_id_crosswalk.csv`: 이전 차선 ID와 수정 ID 대응.
- `node_master.csv`, `link_master.csv`, `lane_master.csv`, `turn_permissions.csv`, `network.json`: 수정한 네트워크와 규칙.
- `network_viewer.html`: 오프라인 지도. 영역 선택에서 C2/C3의 4차선 확대 가능. Link 클릭 정보에 가까운 표식과 해당 차선의 구간별 규칙 표시.
- `reconstructed_network.dxf`: 원본 CAD 좌표에 맞춘 차선 축·Node 및 회전 표식 오버레이.
- `network_overview.png`, `network_detail.png`, `network_only.png`: 수정 시각화.

## 검증 및 재생성

112개 표식의 4통로×4차선×7구간 누락·중복 없음, C2/C3의 2번 차선은 모두 좌회전 전용, 4번 차선은 모두 우회전 전용인지 검사했다. Node 참조 누락·0 이하 길이·Link ID 중복은 0건이다. 112개 원본 도형을 atlas로 출력했으며 누락 차선의 대표 구간과 예외 구간을 시각 대조했다. 이는 기하학적 주행 가능성 검증을 대신하지 않는다.

필요 패키지: ezdxf, numpy, matplotlib. 같은 폴더에서 다음 순서로 실행한다.

```
python audit_vertical_symbols.py
python render_audit.py
python build_network.py
python finalize_revision.py
```

원본 DWG는 수정하지 않았다. 입력 yard_clean.dxf는 이전 DWG 변환본이며, 원 변환 과정의 프록시 객체 binary tag 1건 처리 및 복합 객체 경고는 그대로 적용된다.
'''
(P/'README_KO.md').write_text(text)
(P/'requirements.txt').write_text('ezdxf\nnumpy\nmatplotlib\n')
print(summary)
