"""Rebuild the evidence-backed preliminary yard lane network from cleaned DXF.
CAD unit conversion is provisional: local=(CAD-[180000000,175000000])/1000.
Intersection connectivity is geometric; turn_permissions.csv is mandatory for routing.
"""
from pathlib import Path
import json,csv,math,collections
import numpy as np,ezdxf
class Point:
 geom_type='Point'
 def __init__(self,p=None):self.coords=[] if p is None else [tuple(p)];self.is_empty=p is None
class LineString:
 def __init__(self,p):
  self.p=np.array(p,dtype=float);self.length=float(np.linalg.norm(self.p[1]-self.p[0]));self.wkt='LINESTRING ('+', '.join(f'{x:.7f} {y:.7f}' for x,y in self.p)+')'
 def interpolate(self,t):return Point(self.p[0]+(self.p[1]-self.p[0])*t/self.length)
 def project(self,p):return float(np.dot(np.array(p.coords[0])-self.p[0],(self.p[1]-self.p[0])/self.length))
 def intersection(self,m):
  h,v=(self,m) if abs(self.p[0,1]-self.p[1,1])<1e-8 else (m,self)
  x=v.p[0,0];y=h.p[0,1]
  return Point([x,y]) if min(h.p[:,0])-1e-8<=x<=max(h.p[:,0])+1e-8 and min(v.p[:,1])-1e-8<=y<=max(v.p[:,1])+1e-8 else Point()

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.collections import LineCollection
ROOT=Path(__file__).resolve().parent; OUT=ROOT; D=ezdxf.readfile(ROOT/'yard_clean.dxf');O=np.array([180000000.,175000000.])
def writecsv(name,rows):
 if not rows:return
 with open(OUT/name,'w',encoding='utf-8-sig',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
def local(p):return (np.array(p)[:2]-O)/1000
A=json.load(open(ROOT/'arrows.json'))
for a in A:a.update(kind='straight',source='7_vertex_arrow',rotation='',mirror='')
for e in D.modelspace().query('LWPOLYLINE'):
 if len(e) not in (12,16,17):continue
 p=(np.array(e.get_points('xy'))-O)/1000;wh=np.ptp(p,axis=0)
 if not(.4<min(wh)<2 and 3.5<max(wh)<6.5):continue
 axis=int(np.argmax(wh));tail=[]
 for i in range(len(p)):
  v=p[(i+1)%len(p)]-p[i]
  if abs(np.linalg.norm(v)-.15)<.015 and abs(v[axis])<.02:tail.append((p[i]+p[(i+1)%len(p)])/2)
 if not tail:continue
 t=max(tail,key=lambda x:abs(x[axis]-p[:,axis].mean()));d=np.zeros(2);d[axis]=np.sign(p[:,axis].mean()-t[axis]);c=p.mean(0)
 A.append(dict(handle=e.dxf.handle,layer=e.dxf.layer,x=float(t[0]),y=float(t[1]),dx=float(d[0]),dy=float(d[1]),poly=p.tolist(),kind='turn_only' if len(e)==12 else 'straight_and_turn',source=f'{len(e)}_vertex_arrow',rotation='',mirror=''))
# Block transforms: TH is a straight arrow pointing along local +Y. LT/TL retained for review.
for e in D.modelspace().query('INSERT'):
 if e.dxf.layer!='노면표시' or e.dxf.name not in ['TH','LT','TL']:continue
 p=local(e.dxf.insert);r=math.radians(e.dxf.rotation);d=np.array([-math.sin(r),math.cos(r)])*np.sign(e.dxf.yscale)
 A.append(dict(handle=e.dxf.handle,layer=e.dxf.layer,x=float(p[0]),y=float(p[1]),dx=float(d[0]),dy=float(d[1]),poly=[],kind='straight' if e.dxf.name=='TH' else 'block_turn_review',source=e.dxf.name,rotation=e.dxf.rotation,mirror=e.dxf.xscale<0))
# Remove coincident source symbols while retaining all source handles.
U={}
for a in A:
 k=(round(a['x'],2),round(a['y'],2),round(a['dx'],2),round(a['dy'],2),a['kind'])
 if k in U:U[k]['handle']+=';'+a['handle']
 else:U[k]=a
A=list(U.values())
SYMBOLS=json.load(open(ROOT/'vertical_symbols.json'))
# Replace former partial vertical detections with composite LINE/LWPOLYLINE/ARC audits.
A=[a for a in A if not (506<a['y']<843 and any(lo<a['x']<hi for lo,hi in [(354,377),(717,738),(1079,1099),(1433,1454)]))]
for a in A:a.update(allowed_maneuvers='',audit_symbol_id='',approach_band='',turn_rule_status='not_audited')
for r in SYMBOLS:
 moves=r['movements'].split('|');kind='straight' if moves==['straight'] else ('straight_and_turn' if 'straight' in moves else 'turn_only')
 A.append(dict(handle=r['source_handles'],layer='장치장',x=r['x'],y=r['y'],dx=0.,dy=float(r['dy']),poly=[],kind=kind,source='composite_geometry_audit',rotation='',mirror='',allowed_maneuvers=r['movements'],audit_symbol_id=r['symbol_id'],approach_band=r['band'],turn_rule_status='drawing_symbol_verified'))
for i,a in enumerate(A):a['evidence_id']=f'E{i+1:04d}'
writecsv('direction_evidence.csv',[{k:v for k,v in a.items() if k!='poly'} for a in A])
# Fit a lane to collinear symbols within each yard bank. No cross-bank global snapping.
lanes=[]
banks=[('A',380,718,359.5,733.35),('B',741,1076,720.85,1094.7),('C',1102,1422,1082.2,1449.6837963)]
for bank,x0,x1,xL,xR in banks:
 aa=sorted([a for a in A if x0<a['x']<x1 and 475<a['y']<875 and abs(a['dx'])>.99 and a['kind']=='straight'],key=lambda a:a['y']); groups=[]
 for a in aa:
  if not groups or a['y']-np.mean([v['y'] for v in groups[-1]])>1.0:groups.append([a])
  else:groups[-1].append(a)
 for g in groups:
  y=float(np.median([a['y'] for a in g]));dirs=set(round(a['dx']) for a in g);di=next(iter(dirs)) if len(dirs)==1 else 0
  lanes.append(dict(lane_id=f'H{bank}{len([l for l in lanes if l["zone"]==bank])+1:03d}',axis='H',zone=bank,coords=[[xL,y],[xR,y]],direction=di,evidence=g,geometry_status='inferred_centerline_and_extent',direction_status='arrow_supported' if di else 'conflict'))
# Four explicit lane slots in each of four vertical corridors, with seven local symbol rules each.
for ci in range(1,5):
 for slot in range(1,5):
  rr=[r for r in SYMBOLS if r['corridor']==f'C{ci}' and r['lane_slot']==slot]
  assert len(rr)==7, (ci,slot,len(rr))
  ids={r['symbol_id'] for r in rr};g=[a for a in A if a['audit_symbol_id'] in ids]
  x=float(np.median([r['x'] for r in rr]));ds={r['dy'] for r in rr};assert len(ds)==1
  lanes.append(dict(lane_id=f'V{ci}{slot:02d}',axis='V',zone=f'CORRIDOR_{ci}',coords=[[x,480],[x,870]],direction=next(iter(ds)),evidence=g,geometry_status='arrow_shaft_position_extent_inferred',direction_status='composite_arrow_audited'))
# All lanes have evidence. Gate/north/apron remain explicit review zones instead of invented routes.
for l in lanes:l['line']=LineString(l['coords']);l['cuts']=[0,l['line'].length]
for i,l in enumerate(lanes):
 for m in lanes[i+1:]:
  if l['axis']==m['axis']:continue
  p=l['line'].intersection(m['line'])
  if p.geom_type=='Point' and not p.is_empty:l['cuts'].append(l['line'].project(p));m['cuts'].append(m['line'].project(p))
nodes=[];N={};links=[]
def node(p):
 k=tuple(round(v,5) for v in p)
 if k not in N:
  ni=f'R2N{len(nodes)+1:05d}';N[k]=ni;nodes.append(dict(node_id=ni,x_local=k[0],y_local=k[1],x_cad=O[0]+k[0]*1000,y_cad=O[1]+k[1]*1000,node_type='lane_endpoint_or_geometric_crossing',connectivity='turn_table_required'))
 return N[k]
for l in lanes:
 cuts=sorted(set(round(v,7) for v in l['cuts']))
 for a,b in zip(cuts,cuts[1:]):
  if b-a<.001:continue
  p=list(l['line'].interpolate(a).coords)[0];q=list(l['line'].interpolate(b).coords)[0]
  if l['direction']<0:p,q=q,p
  n1,n2=node(p),node(q);mid=(np.array(p)+q)/2;g=min(l['evidence'],key=lambda e:np.linalg.norm(mid-[e['x'],e['y']]))
  direct='forward' if l['direction'] else 'unknown'
  links.append(dict(link_id=f'R2L{len(links)+1:05d}',lane_id=l['lane_id'],from_node=n1,to_node=n2,direction=direct,direction_status=l['direction_status'],geometry_status=l['geometry_status'],length_cad=round((b-a)*1000,3),length_m_assuming_mm=round(b-a,5),width_m='',zone=l['zone'],source_evidence=g['evidence_id'],nearest_symbol_kind=g['kind'],nearest_symbol_maneuvers=g['allowed_maneuvers'],nearest_symbol_id=g['audit_symbol_id'],source_handles=';'.join(e['handle'] for e in l['evidence']),routing_ready=0,geometry_wkt=LineString([p,q]).wkt))
writecsv('node_master.csv',nodes);writecsv('link_master.csv',links)
writecsv('lane_master.csv',[dict(lane_id=l['lane_id'],axis=l['axis'],zone=l['zone'],direction=l['direction'],direction_status=l['direction_status'],geometry_status=l['geometry_status'],evidence_count=len(l['evidence']),source_evidence=';'.join(a['evidence_id'] for a in l['evidence']),geometry_wkt=l['line'].wkt) for l in lanes])
# Direction-aware symbol restrictions; drawing permission does not verify a specific connector path.
inc=collections.defaultdict(list);out=collections.defaultdict(list)
for l in links:inc[l['to_node']].append(l);out[l['from_node']].append(l)
node_by_id={n['node_id']:n for n in nodes};lane_by_id={l['lane_id']:l for l in lanes};turns=[]
for n in N.values():
 for a in inc[n]:
  for b in out[n]:
   same=a['lane_id']==b['lane_id'];move='straight' if same else 'cross_lane_transition'
   rule=None;symbol_allowed='';state='review_required';reason='Other lane transition not audited'
   if a['lane_id'].startswith('V'):
    lane=lane_by_id[a['lane_id']];dy=lane['direction'];y=node_by_id[n]['y_local']
    upstream=[g for g in lane['evidence'] if (y-g['y'])*dy>=-0.001]
    if upstream:rule=min(upstream,key=lambda g:abs(y-g['y']))
    if not same and b['lane_id'].startswith('H'):
     target=node_by_id[b['to_node']];dx=np.sign(target['x_local']-node_by_id[n]['x_local']);move='left' if -dy*dx>0 else 'right'
    if rule and move in ['straight','left','right']:
     symbol_allowed=move in rule['allowed_maneuvers'].split('|');state='symbol_permits_connector_unverified' if symbol_allowed else 'prohibited_by_symbol';reason='Composite CAD symbol applies to upstream vertical approach; target lane/turn curve remains unverified'
   elif same:state='candidate_straight';reason='Horizontal lane continuation carried forward; not a new turn audit'
   turns.append(dict(via_node=n,from_link=a['link_id'],to_link=b['link_id'],movement=move,permission=state,symbol_permitted=symbol_allowed,source_symbol=rule['audit_symbol_id'] if rule else '',source_evidence=rule['evidence_id'] if rule else '',routing_enabled=0,reason=reason))
writecsv('turn_permissions.csv',turns)
writecsv('movement_rule_master.csv',[dict(rule_id=r['symbol_id'],lane_id=f"V{r['corridor'][1:]}{r['lane_slot']:02d}",band=r['band'],symbol_x=r['x'],symbol_y=r['y'],approach=r['approach'],allowed_maneuvers=r['movements'],straight_allowed='straight' in r['movements'].split('|'),left_allowed='left' in r['movements'].split('|'),right_allowed='right' in r['movements'].split('|'),evidence_status='drawing_symbol_verified',connector_status='target_lane_and_curve_unverified',source_handles=r['source_handles']) for r in SYMBOLS])
# Data-space JSON, explicitly not geographic GeoJSON.
network=dict(schema_version='0.2-vertical-audit',vertical_movement_symbols=SYMBOLS,coordinate_system=dict(type='LOCAL_CAD',cad_origin=O.tolist(),local_scale_divisor=1000,header_INSUNITS=int(D.units),scale_status='millimetre_hypothesis_unverified',tos_transform=None),nodes=nodes,links=links,turn_permissions=turns,direction_evidence=[{k:v for k,v in a.items() if k!='poly'} for a in A])
(OUT/'network.json').write_text(json.dumps(network,ensure_ascii=False,indent=2))
# Analyst-defined space zones; original yard block names are not invented.
zones=[]
for bank,x0,x1,*_ in banks:
 for i,(y0,y1) in enumerate([(503,535),(553,583),(604,635),(664,691),(714,741),(765,792),(818,849)]):zones.append(dict(zone_id=f'Z_{bank}_{i+1}',zone_type='storage_block_approximation',xmin=x0,xmax=x1,ymin=y0,ymax=y1,status='analyst_boundary_review'))
for zid,bb in [('REVIEW_GATE',(150,380,820,1030)),('REVIEW_NORTH',(380,1450,875,1010)),('REVIEW_APRON',(350,1455,410,475))]:zones.append(dict(zone_id=zid,zone_type='unresolved_road_area',xmin=bb[0],xmax=bb[1],ymin=bb[2],ymax=bb[3],status='not_reconstructed'))
writecsv('zone_master.csv',zones)
G=json.load(open(ROOT/'geometry.json'));segs=[]
for e in G:
 p=(np.array(e['p'])-O)/1000
 if p[:,0].min()>1458 or p[:,0].max()<145 or p[:,1].min()>1015 or p[:,1].max()<410:continue
 segs.append(p)
def plot(name,bounds,background=True,labels=False):
 fig,ax=plt.subplots(figsize=(20,11));fig.patch.set_facecolor('#f8fafc');ax.set_facecolor('#f8fafc')
 if background:ax.add_collection(LineCollection(segs,colors='#a8b2bd',linewidths=.22,alpha=.6))
 for l in lanes:
  c='#057ca5' if l['axis']=='H' else '#b65c16';p,q=np.array(l['coords']);ax.plot([p[0],q[0]],[p[1],q[1]],color=c,lw=.8,alpha=.85)
  for t in ([.27,.7] if l['axis']=='H' else []):
   m=p+(q-p)*t;d=(q-p)/np.linalg.norm(q-p)*l['direction'];ax.annotate('',xy=m+d*4,xytext=m-d*4,arrowprops=dict(arrowstyle='-|>',color=c,lw=.8,mutation_scale=6))
  if labels:ax.text(*(p+q)/2,l['lane_id'],fontsize=7,color=c,clip_on=True,rotation=90 if l['axis']=='V' else 0)
 for a in A:
  if bounds[0]<a['x']<bounds[1] and bounds[2]<a['y']<bounds[3]:ax.plot(a['x'],a['y'],'.',ms=1.6,color='#783d9b')
 for r in SYMBOLS:
  if bounds[0]<r['x']<bounds[1] and bounds[2]<r['y']<bounds[3]:
   color='#a23c95' if r['corridor'] in ['C2','C3'] and r['lane_slot'] in [2,4] else '#b65c16'
   ax.add_collection(LineCollection([np.array(p) for p in r.get('geometry',[])],colors=color,linewidths=1.1))
 if labels:
  for n in nodes:
   if bounds[0]<n['x_local']<bounds[1] and bounds[2]<n['y_local']<bounds[3]:ax.plot(n['x_local'],n['y_local'],'o',ms=1.7,color='#172b45')
 for z in zones:
  if z['zone_type']=='unresolved_road_area':
   from matplotlib.patches import Rectangle
   ax.add_patch(Rectangle((z['xmin'],z['ymin']),z['xmax']-z['xmin'],z['ymax']-z['ymin'],facecolor='#d98a12',alpha=.08,edgecolor='none'));ax.text((z['xmin']+z['xmax'])/2,(z['ymin']+z['ymax'])/2,z['zone_id'],ha='center',fontsize=9,color='#8e5b18',clip_on=True)
 ax.set(xlim=bounds[:2],ylim=bounds[2:],xlabel='Local X = (CAD X - 180000000) / 1000; scale provisional',ylabel='Local Y = (CAD Y - 175000000) / 1000; scale provisional');ax.set_aspect('equal');ax.grid(alpha=.15)
 ax.set_title(f'Yard lane reconstruction v0.2 | {len(lanes)} lane chains / {len(links)} links / {len(nodes)} nodes\nBlue: horizontal lanes | Orange: vertical axes | Magenta symbols: restored turn-only lanes | REVIEW: unresolved',fontsize=13,pad=15)
 fig.savefig(OUT/name,dpi=200,bbox_inches='tight');plt.close(fig)
plot('network_overview.png',(145,1460,410,1020));plot('network_detail.png',(350,760,630,820),True,True);plot('network_only.png',(350,1458,475,878),False)
# Keep a compact dataset for an offline interactive viewer.
compact=dict(lanes=[dict(id=l['lane_id'],p=l['coords'],axis=l['axis'],direction=l['direction'],evidence=len(l['evidence']),rules=[dict(id=g['audit_symbol_id'],y=g['y'],moves=g['allowed_maneuvers']) for g in l['evidence'] if g['audit_symbol_id']]) for l in lanes],nodes=[dict(id=n['node_id'],x=n['x_local'],y=n['y_local']) for n in nodes],links=[dict(id=l['link_id'],lane=l['lane_id'],f=l['from_node'],t=l['to_node'],len=l['length_m_assuming_mm'],ev=l['source_evidence'],symbol=l['nearest_symbol_id'],moves=l['nearest_symbol_maneuvers']) for l in links],arrows=[dict(id=a['evidence_id'],x=a['x'],y=a['y'],dx=a['dx'],dy=a['dy'],kind=a['kind'],handle=a['handle'],moves=a['allowed_maneuvers'],symbol=a['audit_symbol_id']) for a in A],zones=zones)
(OUT/'viewer_data.json').write_text(json.dumps(compact,ensure_ascii=False))
# Basic integrity checks and deliberately explicit remaining gaps.
assert all(l['from_node'] in N.values() and l['to_node'] in N.values() and l['length_cad']>0 for l in links)
assert len({l['link_id'] for l in links})==len(links)
used={e['evidence_id'] for l in lanes for e in l['evidence']}
summary=dict(cad_entities=len(D.modelspace()),layers=len(D.layers),direction_evidence=len(A),evidence_used_in_lanes=len(used),evidence_unassigned=len(A)-len(used),lanes=len(lanes),horizontal_lanes=sum(l['axis']=='H' for l in lanes),vertical_lanes=sum(l['axis']=='V' for l in lanes),nodes=len(nodes),links=len(links),turn_candidates=len(turns),routing_ready_links=0,vertical_symbols_audited=len(SYMBOLS),symbol_prohibited_transitions=sum(t['permission']=='prohibited_by_symbol' for t in turns),direction_conflict_lanes=sum(l['direction']==0 for l in lanes),missing_node_references=0,nonpositive_links=0,source_proxy_binary_tags_removed=1)
(OUT/'validation.json').write_text(json.dumps(summary,indent=2));print(summary)
# All direction evidence must have a visible unresolved disposition if not assigned.
writecsv('unassigned_evidence.csv',[dict(evidence_id=a['evidence_id'],x=a['x'],y=a['y'],kind=a['kind'],handle=a['handle'],reason='outside_main_yard_or_complex_turn_requires_review') for a in A if a['evidence_id'] not in used])
