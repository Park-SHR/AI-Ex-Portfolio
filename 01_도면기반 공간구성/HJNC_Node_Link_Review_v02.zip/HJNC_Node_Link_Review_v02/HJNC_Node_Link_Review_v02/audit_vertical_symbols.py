from pathlib import Path
import ezdxf,numpy as np,json,csv,collections,itertools
ROOT=Path(__file__).resolve().parent;D=ezdxf.readfile(ROOT/'yard_clean.dxf');O=np.array([180000000.,175000000.]);segs=[]
for e in D.modelspace():
 t=e.dxftype()
 if t=='LINE':p=(np.array([list(e.dxf.start)[:2],list(e.dxf.end)[:2]])-O)/1000
 elif t=='LWPOLYLINE':
  p=(np.array(e.get_points('xy'))-O)/1000
  if e.closed:p=np.vstack([p,p[0]])
 else:continue
 if not any(lo<p[:,0].mean()<hi for lo,hi in [(354,377),(717,738),(1079,1099),(1433,1454)]) or not(506<p[:,1].mean()<843):continue
 for a,b in zip(p,p[1:]):
  if np.linalg.norm(b-a)>1e-5:segs.append((a,b,e.dxf.handle))
def key(p):return tuple(np.round(p,4))
adj=collections.defaultdict(list)
for a,b,h in segs:adj[key(a)].append((b,h));adj[key(b)].append((a,h))
heads=[];tails=[]
for v,others in adj.items():
 v=np.array(v)
 for (a,h1),(b,h2) in itertools.combinations(others,2):
  mid=(a+b)/2;u=v-mid;base=a-b
  # CAD arrow head geometry: pointed straight tip, broad turn tip.
  straight=abs(base[1])<.002 and abs(abs(base[0])-.6)<.03 and abs(u[0])<.003 and min(abs(abs(u[1])-2.2),abs(abs(u[1])-1.71))<.03
  turn=abs(base[0])<.002 and abs(abs(base[1])-2.2)<.03 and abs(u[1])<.003 and abs(abs(u[0])-.6)<.03
  if straight or turn:
   dd=u/np.linalg.norm(u);heads.append(dict(x=float(v[0]),y=float(v[1]),dx=int(round(dd[0])),dy=int(round(dd[1])),handles=sorted(set([h1,h2]))))
for a,b,h in segs:
 if abs(a[1]-b[1])>.002 or abs(abs(a[0]-b[0])-.15)>.015:continue
 va=[(q-a,hh) for q,hh in adj[key(a)] if abs(q[0]-a[0])<.002 and abs(q[1]-a[1])>.3]
 vb=[(q-b,hh) for q,hh in adj[key(b)] if abs(q[0]-b[0])<.002 and abs(q[1]-b[1])>.3]
 for (u,h1),(v,h2) in itertools.product(va,vb):
  if np.sign(u[1])==np.sign(v[1]):
   p=(a+b)/2;tails.append(dict(x=float(p[0]),y=float(p[1]),dy=int(np.sign(u[1])),handles=sorted(set([h,h1,h2]))))
heads=list({(round(h['x'],3),round(h['y'],3),h['dx'],h['dy']):h for h in heads}.values());tails=list({(round(t['x'],3),round(t['y'],3),t['dy']):t for t in tails}.values())
records=[]
for t in sorted(tails,key=lambda t:(t['x'],t['y'])):
 hh=[h for h in heads if abs(h['x']-t['x'])<1.5 and -.3<(h['y']-t['y'])*t['dy']<6.3]
 if not hh:continue
 moves=[]
 for h in hh:
  if h['dy']==t['dy']:moves.append('straight')
  elif h['dx']:moves.append('left' if -t['dy']*h['dx']>0 else 'right')
  else:moves.append('reverse_review')
 ci=next(i+1 for i,(lo,hi) in enumerate([(354,377),(717,738),(1079,1099),(1433,1454)]) if lo<t['x']<hi)
 band=int(np.argmin(abs(np.array([516,567,618,675,726,777,834])-t['y'])))+1
 records.append(dict(symbol_id=f'VS{len(records)+1:03d}',corridor=f'C{ci}',band=band,x=t['x'],y=t['y'],approach='CAD_Y_PLUS' if t['dy']>0 else 'CAD_Y_MINUS',dy=t['dy'],movements='|'.join(sorted(set(moves))),source_handles=';'.join(sorted(set(t['handles']+sum([h['handles'] for h in hh],[])))),head_count=len(hh),head_vectors=json.dumps([[h['dx'],h['dy']] for h in hh]),heads=hh))
# Lane slots are left-to-right spatial order within each corridor.
for c in ['C1','C2','C3','C4']:
 rr=[r for r in records if r['corridor']==c];xx=[]
 for r in sorted(rr,key=lambda r:r['x']):
  if not xx or r['x']-np.mean(xx[-1])>1:xx.append([r['x']])
  else:xx[-1].append(r['x'])
 for r in rr:r['lane_slot']=int(np.argmin([abs(r['x']-np.mean(g)) for g in xx]))+1
print('segments',len(segs),'heads',len(heads),'tails',len(tails),'symbols',len(records))
for c in ['C1','C2','C3','C4']:
 for slot in range(1,5):
  rr=[r for r in records if r['corridor']==c and r['lane_slot']==slot];print(c,slot,'x',round(np.mean([r['x'] for r in rr]),4),'directions',collections.Counter(r['approach'] for r in rr),'moves',collections.Counter(r['movements'] for r in rr),'bands',[r['band'] for r in rr])
(ROOT/'vertical_symbols.json').write_text(json.dumps(records,ensure_ascii=False,indent=2))
with open(ROOT/'vertical_symbols.csv','w',encoding='utf-8-sig',newline='') as f:
 rows=[{k:v for k,v in r.items() if k!='heads'} for r in records];w=csv.DictWriter(f,fieldnames=rows[0]);w.writeheader();w.writerows(rows)
