from pathlib import Path
import json,csv,collections
import numpy as np,ezdxf
from ezdxf import path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.collections import LineCollection
ROOT=Path(__file__).resolve().parent;D=ezdxf.readfile(ROOT/'yard_clean.dxf');O=np.array([180000000,175000000]);R=json.load(open(ROOT/'vertical_symbols.json'));geom=[]
for e in D.modelspace():
 if e.dxftype() not in ['LINE','LWPOLYLINE','ARC']:continue
 try:p=(np.array([list(v)[:2] for v in path.make_path(e).flattening(20)])-O)/1000
 except:continue
 if not len(p):continue
 if not any(lo<p[:,0].mean()<hi for lo,hi in [(354,377),(717,738),(1079,1099),(1433,1454)]) or not 506<p[:,1].mean()<843:continue
 if max(np.ptp(p,axis=0))<8:geom.append((e.dxf.handle,p))
for r in R:
 pp=[(h,p) for h,p in geom if abs(p[:,0].mean()-r['x'])<1.6 and -.4<(p[:,1].mean()-r['y'])*r['dy']<6.4]
 r['all_symbol_handles']=';'.join(sorted(set(h for h,p in pp)))
 r['source_handles']=r['all_symbol_handles']
 r['geometry']=[p.tolist() for h,p in pp]
(ROOT/'vertical_symbols.json').write_text(json.dumps(R,ensure_ascii=False,indent=2))
with open(ROOT/'vertical_symbols.csv','w',encoding='utf-8-sig',newline='') as f:
 rr=[{k:v for k,v in r.items() if k not in ['heads','geometry']} for r in R];w=csv.DictWriter(f,fieldnames=rr[0]);w.writeheader();w.writerows(rr)
short={'straight':'S','left':'L','right':'R'}
def cell(ax,c,b,large=False):
 rows=sorted([r for r in R if r['corridor']==c and r['band']==b],key=lambda r:r['lane_slot']);xmin=min(r['x'] for r in rows)-2;xmax=max(r['x'] for r in rows)+2
 p_all=np.concatenate([np.array(p) for r in rows for p in r['geometry']]);ymin=p_all[:,1].min();ymax=p_all[:,1].max();ax.set(xlim=(xmin,xmax),ylim=(ymin-2.1,ymax+2));ax.set_aspect('equal');ax.axis('off')
 for r in rows:
  missing=c in ['C2','C3'] and r['lane_slot'] in [2,4];color='#a23c95' if missing else '#187995'
  ax.axvline(r['x']-1.8,color='#d5dce3',lw=.6);ax.add_collection(LineCollection([np.array(p) for p in r['geometry']],colors=color,linewidths=1.3 if large else .85))
  m='+'.join(short[x] for x in r['movements'].split('|'));label=f"{c}-{r['lane_slot']}\n{'DOWN' if r['dy']<0 else 'UP'} / {m}"
  ax.text(r['x'],ymin-0.7,label,ha='center',va='top',fontsize=12 if large else 8,color=color)
  ax.text(r['x'],ymax+.6,r['symbol_id'],ha='center',fontsize=9 if large else 6,color='#526376')
 ax.set_title(f'{c} | band {b} | original CAD symbols',fontsize=15 if large else 10,pad=8)
fig,axs=plt.subplots(1,2,figsize=(18,8),layout='constrained')
for ax,c in zip(axs,['C2','C3']):cell(ax,c,6,True)
fig.suptitle('Four lanes per internal corridor: the missing turn-only lanes\nS = straight | L = driver-relative left | R = driver-relative right\nPurple = omitted in v0.1; reconstructed from LINE + ARC + LWPOLYLINE',fontsize=18)
fig.savefig(ROOT/'vertical_four_lane_detail.png',dpi=220);plt.close(fig)
fig,axs=plt.subplots(7,4,figsize=(22,28),layout='constrained')
for i,b in enumerate(range(7,0,-1)):
 for j,c in enumerate(['C1','C2','C3','C4']):cell(axs[i,j],c,b)
fig.suptitle('Full vertical lane symbol audit: 4 corridors x 4 lanes x 7 bands = 112 symbols\nOriginal CAD outlines | S straight, L left, R right (relative to driving direction) | Purple: formerly omitted',fontsize=17)
fig.savefig(ROOT/'vertical_symbol_atlas.png',dpi=180);plt.close(fig)
print('rendered and supplemented ARC provenance',len(R))
