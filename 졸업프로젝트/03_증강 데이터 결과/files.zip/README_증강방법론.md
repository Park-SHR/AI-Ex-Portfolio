# 시나리오 기반 증강 데이터 — 산출물 안내

## 파일 구성

| 파일 | 내용 |
|---|---|
| `scenario_augmented_trajectories.csv` | **최종 시나리오 증강 궤적** (300개 중 219개 목표밴드 도달, 6,291행) |
| `simple_pattern_augmented_trajectories.csv` | 이전 단계 결과물(단순 패턴 확장 버전, 참고용) |
| `band_weights.json` | 블록→밴드 근사매핑 및 실측기반 밴드 가중치 |
| `real_transitions_v03.json` | v0.3 망 기준 실측 Link 전이표(167,041건) |
| `snapped_observations.csv` | 실측 TOS 위치를 v0.3망에 스냅한 원자료(1,328,484건) |
| `scenario_augmented_sample.png` | 궤적 샘플 25개 시각화 |

## scenario_augmented_trajectories.csv 컬럼

- `synthetic_yt_id`: 합성 YT 식별자(SC0001~SC0219)
- `target_band_demand_scenario`: 이 궤적이 향하는 목표 도로밴드(RB01~RB08), 실측기반 가중치로 추첨됨
- `step_index`, `link_id`, `road_band_id`, `lane_id`: 경로상 각 스텝의 위치
- `step_basis`: 그 스텝이 `real_transition_frequency`(실측 전이 반영) 인지 `shortest_path_fallback`(실측 없어 최단경로로만 이동) 인지 구분 — **68%가 실측 기반**

## 핵심 한계 (반드시 함께 인용)

1. 좌표변환(TOS→CAD local, +358.0/+469.75)은 v0.3 자체가 "candidate, not authoritative"로 명시한 미확정 값
2. 블록↔밴드 매핑은 구-신 두 네트워크 간 근사 대응(5~24 unit 오차), RB01·RB02는 대응 구블록이 없어 스무딩만 적용
3. 밴드 가중치의 근거 표본은 791건 (전체 작업이벤트 342,748건의 0.2%) — 전체 원본 TOS 작업로그 미확보로 인한 제약
4. **"검증된 SOP"가 아니라 "실측 힌트가 있는 가정 시나리오"**로 인용할 것
